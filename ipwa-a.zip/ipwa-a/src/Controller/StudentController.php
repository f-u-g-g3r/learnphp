<?php

namespace App\Controller;

use App\Entity\Student;
use App\Exception\StudentNotFoundException;
use App\Repository\StudentRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\InputBag;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class StudentController extends AbstractController
{
    #[Route('/students', methods: ['GET'])]
    public function add(EntityManagerInterface $entityManager, Request $request): Response
    {
        $data = $request->getPayload();

        $student = new Student();
        $student = $this->toStudent($data, $student);

        $entityManager->persist($student);
        $entityManager->flush();

        return new Response('OK', 200);
    }

    #[Route('/students', methods: ['GET'])]
    public function all(StudentRepository $repository): JsonResponse
    {
        $students = $repository->findAll();

        $studentsInJson = array_map(
            function (Student $student) {
                return $this->toKeyValueArray($student);
            },
            $students
        );

        return new JsonResponse($studentsInJson, 200);
    }

    /**
     * @throws StudentNotFoundException
     */
    #[Route('/students/{id}', methods: ['GET'])]
    public function one(StudentRepository $repository, int $id): JsonResponse
    {

        $student = $repository->find($id) or
            throw new StudentNotFoundException("Could not find student ".$id);

        return new JsonResponse($this->toKeyValueArray($student), 200);
    }

    /**
     * @throws StudentNotFoundException
     */
    #[Route('/students/{id}', methods: ['PUT'])]
    public function update(EntityManagerInterface $entityManager, Request $request, int $id): Response
    {
        $student = $entityManager->getRepository(Student::class)->find($id) or
            throw new StudentNotFoundException("Could not find student ".$id);

        $newStudent = $request->getPayload();

        $student = $this->toStudent($newStudent, $student);

        $entityManager->persist($student);
        $entityManager->flush();

        return new Response('OK', 200);
    }

    /**
     * @throws StudentNotFoundException
     */
    #[Route('/students/{id}', methods: ['DELETE'])]
    public function delete(EntityManagerInterface $entityManager, int $id): Response
    {
        $student = $entityManager->getRepository(Student::class)->find($id) or
            throw new StudentNotFoundException("Could not find student ".$id);

        $entityManager->remove($student);
        $entityManager->flush();

        return new Response('ok', 200);
    }

    private function toKeyValueArray(Student $student): array
    {
        return [
            'id' => $student->getId(),
            'firstname' => $student->getFirstname(),
            'lastname' => $student->getLastname(),
            'email' => $student->getEmail(),
            'password' => $student->getPassword(),
            'phone' => $student->getPhone(),
            'age' => $student->getAge()
        ];
    }

    private function toStudent(InputBag $data, Student $student): Student
    {
        if ($data->get('firstname') != null) $student->setFirstname($data->get('firstname'));
        if ($data->get('lastname') != null) $student->setLastname($data->get('lastname'));
        if ($data->get('email') != null) $student->setEmail($data->get('email'));
        if ($data->get('password') != null) $student->setPassword($data->get('password'));
        if ($data->get('age') != null) $student->setAge($data->get('age'));
        if ($data->get('phone') != null) $student->setPhone($data->get('phone'));

        return $student;
    }
}
